<?php

class UsersTableSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{		
		DB::table('users')->delete();
		/*DB::table('users')->insertGetId(
		array('name' => 'tutorone', 'password' => 'tutorone', 'nrc' => 'MA766667', 'email' => 'tutorone@test.com', 'birthday' => '1990-5-12',
		'phone' => '876567789', 'address' => 'no.7,tone street,tone city', 'role' => '1', 'created_at' => date('y-m-d H:i:s'), 'updated_at' => date('y-m-d H:i:s')));
	*/
	}

}
