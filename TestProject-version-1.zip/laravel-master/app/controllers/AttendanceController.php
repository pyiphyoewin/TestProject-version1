<?php

class AttendanceController extends BaseController {

	public function __construct()
	{
		$this->beforeFilter('auth',array('except' => 'auth/login'));
	}
	
	public function getCreate(){
		$flag="create";
		if(Session::get('role') == "2"){
			$user = User::find(Session::get('userId'));
			$courses = User::find($user->id)->courses;
			$checkCourse = new Course;
			return View::make('Attendance.attendanceCreate', array('user' => $user, 'checkCourse' => $checkCourse, 'courses' => $courses, 'flag' => $flag));
		}
		$users = User::where('role','=','2')->get();
		$courses = Course::all();
		$checkCourse = new Course;
		return View::make('Attendance.attendanceCreate', array('users' => $users, 'checkCourse' => $checkCourse, 'courses' => $courses, 'flag' => $flag));
	}
	
	public function postCreate(){
		$attendance = DB::table('attendances')
			->where('userId','=',Input::get('userId'))
			->where('courseId','=',Input::get('courseId'))
			->whereBetween('created_at',array(date('Y-m-d 00:00:00'),date('Y-m-d 23:59:59')))
			->get();
		if(!empty($attendance)){
			Session::flash('error', "You cannot register attendance two times in a day!");
			return Redirect::to('attendance/create');
		}
		$data = Input::all();
		Session::flash('values', $data);
		Session::put('flag', 'create');
		return Redirect::to('attendance/confirm');
	}
	
	public function getConfirm(){
		if(Session::get('flag') == "delete"){
			$attendance = Attendance::find(Session::get('id'));
			$user = User::find($attendance->userId);
			$data = array('attendanceId' => $attendance->id, 'userId' => $user->id);
			$course = Course::find($attendance->courseId);
			return View::make('Attendance.attendanceConfirm', array('user' => $data, 'course' => $course, 'userName' => $user->name));
		}
		$data = Session::get('values');
		$course = Course::find($data['courseId']);
		$user = User::find($data['userId']);
		return View::make('Attendance.attendanceConfirm', array('user' => $data, 'course' => $course, 'userName' => $user->name));
	}
	
	public function postConfirm(){
		if(Session::get('flag') == "delete"){
			$attendance = Attendance::find(Input::get('attendanceId'));
			$attendance->delete();
			return Redirect::to('attendance/list');
		}elseif(Session::get('flag') == "create"){
			$attendance = new Attendance;
		}else{
			$attendance = Attendance::find(Input::get('attendanceId'));
		}
		$attendance->userId = Input::get('userId');
		$attendance->courseId = Input::get('courseId');
		$attendance->status = "disapprove";
		$attendance->save();
			
		Session::forget('flag');
		return Redirect::to('attendance/list');
	}
	
	public function getList(){		
		if(Session::get('role') == "2"){
			$attendances = DB::table('attendances')
				->join('users','userId','=','users.id')
				->join('courses','courseId','=','courses.id')
				->where('attendances.userId', '=', Session::get('userId'))
				->select('attendances.id','users.name as userName','courses.name','attendances.status','attendances.created_at','attendances.updated_at')
				->get();
		}
		else{
			$attendances = DB::table('attendances')
				->join('users','userId','=','users.id')
				->join('courses','courseId','=','courses.id')
				->select('attendances.id','users.name as userName','courses.name','attendances.status','attendances.created_at','attendances.updated_at')
				->get();
		}
		
		return View::make('Attendance.attendanceList')->with('attendances',$attendances);
	}
	
	public function getEdit($id){
		$flag="edit";
		$attendance = Attendance::find($id);
		if($attendance->status == "approved"){
			Session::flash('error', "You cannot update approved attendance!");
			return Redirect::to('attendance/list');
		}
		$user = User::find($attendance->userId);
		$checkCourse = Course::find($attendance->courseId);
		$courses = User::find($user->id)->courses;
		return View::make('Attendance.attendanceCreate', array('attendanceId' => $id,'user' => $user, 'checkCourse' =>$checkCourse, 'courses' => $courses, 'flag' => $flag));
	}
	
	public function postEdit(){
		$data = Input::all();
		Session::flash('values', $data);
		Session::put('flag', 'edit');
		return Redirect::to('attendance/confirm');
	}
	
	public function getDelete($id){
		$attendance = Attendance::find($id);
		if($attendance->status == "approved"){
			Session::flash('error', "You cannot delete approved attendance!");
			return Redirect::to('attendance/list');
		}
		Session::flash('id',$id);
		Session::put('flag', 'delete');
		return Redirect::to('attendance/confirm');
	}
	
	
	public function postApproved(){
		$data = Input::get('data');
		foreach($data as $checkId){
			Attendance::where('id','=',$checkId)->update(array('status' => "approved"));
		}
		return Redirect::to('attendance/list');
	}
	
	public function postDisapproved(){
		$data = Input::get('data');
		foreach($data as $checkId){
			Attendance::where('id','=',$checkId)->update(array('status' => "disapproved"));
		}
		return Redirect::to('attendance/list');
	}

}