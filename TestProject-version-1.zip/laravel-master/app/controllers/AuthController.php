<?php

class AuthController extends BaseController {

	/**	 
	 * login function
	 *
	 * @return redirect to login page
	 */
	public function getIndex()
	{	
		$pass=0;
		return View::make('Login.login')->with('pass', $pass);
	}
	
	/**	 
	 * Validating login information
	 *
	 * @return login confirmation
	 */
	public function postLogin()
	{	
		$pass=1;
		$credentials = array(
		'email' => Input::get('email'),
		'password' => Input::get('password'));
		if(Auth::attempt($credentials))
		{
			$email = Input::get('email');
			$users = User::where('email', '=' ,$email)->get();
			$user = $users[0];
			Session::put('userId', $user->id);
			Session::put('name', $user->name);
			Session::put('role', $user->role);			
			if($user->role == "2")
			{
				return Redirect::to('attendance/create');
			}
			else
			{
				return Redirect::to('attendance/list');
			}
		}
		else
		{
			return View::make('Login.login')->with('pass',$pass);
		}
	}
	
	/**	 
	 * Logout function
	 *
	 * @return Redirect to home page
	 */
	public function getLogout()
	{
		Auth::logout();
		
		return Redirect::to('/login');
	}
	
}
