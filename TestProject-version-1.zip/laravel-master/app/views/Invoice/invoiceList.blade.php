<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Invoice Registration</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo asset("packages/css/bootstrap.min.css"); ?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo asset("packages/css/plugins/metisMenu/metisMenu.min.css"); ?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo asset("packages/css/sb-admin-2.css"); ?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo asset("packages/css/font-awesome.min.css"); ?>" rel="stylesheet" type="text/css">

    <!-- DataTables CSS -->
    <link href="<?php echo asset("packages/css/plugins/dataTables.bootstrap.css"); ?>" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Student Test Project</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li class="divider"></li>
                        <li><a href="{{ asset('/logout') }}"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="{{ asset('attendance/create') }}"><i class="fa fa-dashboard fa-fw"></i> Create Attendance</a>
                        </li>
						<li>
                            <a href="{{ asset('attendance/list') }}"><i class="fa fa-dashboard fa-fw"></i> Attendance List</a>
                        </li>
						<li>
                            <a href="{{ asset('invoice/create') }}"><i class="fa fa-dashboard fa-fw"></i> Create Invoice</a>
                        </li>
						<li>
                            <a href="{{ asset('invoice/list') }}"><i class="fa fa-dashboard fa-fw"></i> Invoice List</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Inovice List Page</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Invoice List Table
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables">
                                    <thead>
                                        <tr>
                                            <th>Student Name</th>
                                            <th>Course Name</th>
                                            <th>Sessions</th>
                                            <th>Start Date</th>
											<th>End Date</th>
											<th>Fee</th>
											<th>Created Date</th>
											<th>Updated Date</th>
											<th>Functions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									@foreach($invoices as $invoice)
                                        <tr>
                                            <td>{{ $invoice->userName }}</td>
                                            <td>{{ $invoice->name }}</td>
                                            <td>{{ $invoice->sessions }}</td>
											<td>{{ $invoice->startDate }}</td>
											<td>{{ $invoice->endDate }}</td>
											<td>{{ $invoice->fees }}</td>
											<td>{{ $invoice->created_at }}</td>
											<td>{{ $invoice->updated_at }}</td>
                                            <td><a href="{{ asset('invoice/edit').'/'. $invoice->id }}" style="margin-right: 10px;"><i class="fa fa-edit"></i></a><a href="{{ asset('invoice/delete').'/'. $invoice->id }}"><i class="fa fa-times"></i></a></td>
                                        </tr>
									@endforeach
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery Version 1.11.0 -->
    <script src="<?php echo asset("packages/js/jquery-1.11.0.js"); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo asset("packages/js/bootstrap.min.js"); ?>"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo asset("packages/js/plugins/metisMenu/metisMenu.min.js"); ?>"></script>

    <!-- Custom Theme JavaScript -->
    

    <!-- DataTables JavaScript -->
    <script src="<?php echo asset("packages/js/plugins/dataTables/jquery.dataTables.js"); ?>"></script>
    <script src="<?php echo asset("packages/js/plugins/dataTables/dataTables.bootstrap.js"); ?>"></script>

    <!-- Custom Theme JavaScript -->
	<script src="<?php echo asset("packages/js/sb-admin-2.js"); ?>"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables').dataTable();
    });
    </script>

</body>

</html>
