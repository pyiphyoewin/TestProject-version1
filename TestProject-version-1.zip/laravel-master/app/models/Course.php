<?php

class Course extends Eloquent
{
	protected $table = 'courses';
	
	public function users()
	{
		return $this->belongsToMany('User', 'user_course','userId','courseId')->withTimeStamps();
	}
}